## Assignment 2 - Snakes and Ladders
Giorgos Stivaktakis / csd4300

### libs
1.  bootstrap        

### before run
npm install

### run
open **snakes_ladders_csd.html** in browser  

### notes
1.  The game is played by 2 players.
2.  Swords effect is implemented.