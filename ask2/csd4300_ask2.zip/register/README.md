## Assignment 2 - Register
Giorgos Stivaktakis / csd4300

### libs
1.  bootstrap       
2.  bootstrap icons
3.  express 

### before run
npm install

### run
open **ask2.html** in browser  
localhost is preferred  
python -m http.server <port>

