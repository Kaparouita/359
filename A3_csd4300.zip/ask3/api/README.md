## 359-backend

This the backend for the 359 project. It is a RESTful API that is built using Go and PostgreSQL.

### Setup
1. Start the PostgreSQL server : docker-compose up
2. Run the server : go run main.go


