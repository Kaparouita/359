package domain

type Response struct {
	StatusCode int
	Message    string
}
